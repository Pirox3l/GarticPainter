package main;
import java.awt.Color;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class GUI implements ActionListener {
	private static String Url;
	private static JTextField userText;
	private static JLabel label;
	private static JFrame frame;
	private static JPanel panel;

	public static void main(String[] args) {
		
		panel = new JPanel();
		frame = new JFrame();
		frame.setSize(350, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("GarticPainter");
		frame.add(panel);
		panel.setLayout(null);
		
		label = new JLabel("Enter a File Path: ");
		label.setBounds(10, 20, 120, 25);
		panel.add(label);
		
		userText = new JTextField();
		userText.setBounds(120, 20, 165, 25);
		panel.add(userText);
		
		JButton button = new JButton("Start Drawing");
		button.setBounds(10, 50, 120, 25);
		panel.add(button);
		button.addActionListener(new GUI());
		
		frame.setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Url = userText.getText();
		try {
			draw(Url);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	public static void draw(String Url) throws Exception {
		File file = new File(Url);
		Robot robot = new Robot();
		
		robot.setAutoDelay(100);
		robot.keyPress(18);
		robot.keyPress(9);
		robot.keyRelease(18);
		robot.keyRelease(9);
		robot.mouseMove(493, 953);
		robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
		robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);

		BufferedImage image = ImageIO.read(file);
		int totalPixels = image.getHeight() * image.getWidth();
		Color[] colors = new Color[totalPixels];
		int i = 0;
		int x = 0;
		int y = 0;
		int cNum = 0;
		
		ArrayList<String> colorlist = new ArrayList<String>();

		do {
			x = 0;
			while (x < image.getWidth()) {
				y = 0;
				while (y < image.getHeight()) {


					colors[i] = new Color(image.getRGB(x, y));
					String hex = String.format("#%02x%02x%02x", colors[i].getRed(), colors[i].getGreen(),
							colors[i].getBlue());

					if (!colorlist.contains(hex)) {
						colorlist.add(hex);
					}

					if (i < 1) {

						robot.setAutoDelay(16);

						robot.mouseMove(308, 708);

						robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
						robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
						robot.mouseMove(350, 990);

						robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
						robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);

						robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
						robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);

						robot.mouseMove(343, 960);

						robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
						robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);

						int r = 1;
						while (r < 7) {

							int keyCode = KeyEvent.getExtendedKeyCodeForChar(colorlist.get(cNum).charAt(r));


							robot.keyPress(keyCode);
							robot.keyRelease(keyCode);

							r++;
						}

						robot.setAutoDelay(1);

						robot.mouseMove(495, 950);
						robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
						robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);

					}

					if (hex.equals(colorlist.get(cNum))) {

						robot.mouseMove(430 + x * 2, 252 + y * 2);

						robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);

					}

					// optimize by looking for repetitive colours and draw line instead of
					// individual pixels
					if (y < image.getHeight() - 1) {

						Color nextColor = new Color(image.getRGB(x, y + 1));

						int c = 1;
						while (colors[i].equals(nextColor) && y + c < image.getHeight()) {

							nextColor = new Color(image.getRGB(x, y + c));
							c++;

						}

						System.out.println(x + " " + y + " " + c);
						System.out.println("c:" + c + " color: " + colors[i]);

						if (i != x * image.getHeight() + y) {
							System.out.println("Something is wrong.");
							throw new Exception("Sumthins wrong.");
						}


			

						if (hex.equals(colorlist.get(cNum))) {

							robot.mouseMove(430 + x * 2, (252 + (y * 2) + (c * 2)));
							robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);

						}

						y += c;
						i += c;

					} else {
						y++;
						i++;
						robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
					}


				}
				y = 0;
				x++;
			}
			i = 0;

			System.out.println(colorlist.get(cNum).toString());
			cNum++;
		} while (cNum < colorlist.size());
		System.out.println("Done");

	}
	
}
